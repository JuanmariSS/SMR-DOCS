**CoalaWeb Social Links** is a Joomla extension designed to help site visitors share content on your site as well as follow you through a variety of social networks. You can choose which **Share** and **Follow Us** links to display depending on your website needs plus it's packed full of other configuration options to make it as flexible as possible.

### Component options and features
- Easy to use layout
- Centralized options
- Quick launch help
- Joomla integrated updates
- Language support
- Facebook App ID integration
- Twitter via integration
- Twitter hashtag integration
- Component Permission Manager
- Facebook JS loading
- Two Facebook sharing systems

### Social Module options and features
- 7 Share options
- 30 Follow US options
- 5 Icon styles
- 5 Hover effects
- 5 Icon sizes
- 1 Layout
- Retina support
- Popup options
- Easily create custom icon style
- Module styling
- Title customization options
- Share This customization options
- Follow Us customization options
- 1 Custom Follow US option
- Custom text fields

## Page Module options and features
- HTML 5
- Various layout options
- Various widget size Options
- Display profile photos
- Display header image
- Small header image option
- Display recent posts
- Timeline, events and messages selector

## Tweet Module options and features
- Max Tweets
- Display title
- Title formatting and alignment
- Set and display custom text
- Content format and alignment
- Break links option

### Languages

**Need CoalaWeb Social Links in a different language?**

[Language Packs](https://coalaweb.com/downloads/language-packs/joomla-extensions) thanks to **Community Translators** and hosted on [Transifex](https://www.transifex.com/coalaweb/).

### Support

**Need help with CoalaWeb Social Links?**

1.  Try the [Documentation](https://coalaweb.com/support/documentation/category/social-links)
2.  Search the [Forum](https://coalaweb.com/forum/index) to see if your question has already been answered. 
3.  Start a new topic.