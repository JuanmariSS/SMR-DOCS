DROP TABLE IF EXISTS `#__cwgears`;
DROP TABLE IF EXISTS `#__cwgears_schedule`;
DROP TABLE IF EXISTS `#__coalaweb_common`;
