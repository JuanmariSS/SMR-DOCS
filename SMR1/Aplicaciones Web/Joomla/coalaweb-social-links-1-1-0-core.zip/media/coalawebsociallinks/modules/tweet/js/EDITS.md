## Changes to original class

I have added the date formatting code snippet to the data only option, this allows easy date formatting. If affects line 295 to 318.

[Fiddle](https://jsfiddle.net/CoalaWeb/5afpkuzh/3/)

