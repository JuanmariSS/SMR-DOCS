DROP TABLE IF EXISTS `#__cwsocial_metafields`;
DROP TABLE IF EXISTS `#__cwsocial_count`;
