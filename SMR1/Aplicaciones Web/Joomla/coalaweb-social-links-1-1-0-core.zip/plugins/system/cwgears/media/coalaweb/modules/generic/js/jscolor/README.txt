The jscolor javascript code is  maintained by Honza Odvarko
(http://odvarko.cz/) and released under the GNU Lesser General Public License
(http://www.gnu.org/copyleft/lesser.html)
See http://jscolor.com/

