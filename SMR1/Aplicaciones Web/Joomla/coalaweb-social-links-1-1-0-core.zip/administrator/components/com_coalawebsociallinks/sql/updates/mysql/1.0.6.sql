ALTER TABLE `#__cwsocial_count` DROP COLUMN `google`;
ALTER TABLE `#__cwsocial_count` DROP COLUMN `stumbleupon`;