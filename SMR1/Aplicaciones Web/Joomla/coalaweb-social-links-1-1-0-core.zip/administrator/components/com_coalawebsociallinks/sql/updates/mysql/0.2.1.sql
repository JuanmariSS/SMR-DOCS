ALTER TABLE `#__cwsocial_metafields` 
ADD COLUMN `menu_id` int(11) unsigned NULL COMMENT 'FK to the #__menu table.';